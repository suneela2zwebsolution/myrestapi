from django.urls import path
from accounts import views

urlpatterns = [
    path('register/user/', views.UserRegistrationView.as_view(),name='register'),
    path('login/user/', views.UserLoginView.as_view(),name='login'),


]