from rest_framework import serializers
from accounts.models import User


class UserRegistrationSerializer(serializers.ModelSerializer):
    password2 = serializers.CharField(
        write_only=True,
        required=True,
        # style={'input_type': 'password', 'placeholder': 'Password(Again)'}
    )
    class Meta:
        model = User
        fields = ('email','name','tc','date_of_birth','password','password2')
        extra_kwargs = {
            'password':{'write_only':True}
        }

    def validate(self, attrs):
        password1=attrs.get('password')
        password2=attrs.get('password2')
        if password1!=password2:
            raise serializers.ValidationError('Password maissmatch')
        return attrs
    
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


class UserLoginSerializer(serializers.ModelSerializer):
    email = serializers.EmailField()
    class Meta:
        model = User
        fields = ('email','password')